import axios from 'axios';
import React, { useState } from 'react'
import Navbar from './Navbar';

const Viewcontact = () => {
    const [view,setView]=useState([])
    axios.get("http://localhost:8080/viewblog").then((response) => {
          //console.log("response");
          setView(response.data);
        });

  return (
    <div>
      <Navbar/>
      <div class="container">
    <div class="row">
        <div class="col col-lg-12 col-xl-12 col-xxl-12">
            <div class="row g-2">
                <div class="col -lg-12 col-xl-12 col-xxl-12">
                   
                   <h1 style={{
                            textAlign:"center",
                            color:"rgb(11, 16, 87)"
                            }}><b>LOGIN HERE</b></h1><br/>
                    <input type="text" placeholder='Email'   class="form-control"/>
                    <br/>
                </div>
                <div class="col col-lg-12 col-xl-12 col-xxl-12">
                    
                    <input type="text" placeholder='Password'   class="form-control"/>
                    <br/>
                </div>
                
               
                <div class="col col-lg-12 col-xl-12 col-xxl-12">
              
                <button type="button" style={{margin:"auto",display:"block"}} class="btn btn-primary">Login</button>
                <br/>

                </div>
            </div>
        </div>
    </div>
</div>
      </div>
  )
}

export default Viewcontact